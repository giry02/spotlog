import { useMemo, useState } from 'react';
import { ArrowLeft, Bookmark, MapPin, Plus, Search } from 'lucide-react';
import type { Journey, Place, PlaceKind } from './data';
import { BottomSheet, useBottomSheetDetail } from './BottomSheet';
import { PhotoCredit } from './PublicTourismCredit';
import { Button, Field } from './ui';
import { distanceBetween, nearbyCandidates } from './tripPlan';

export type StayChoice = { dayId: string; nights: number; fixed: boolean };
type Props = { journey: Journey; dayId: string; anchor: Place; catalog: Place[]; savedPlaces: Place[]; initialKind?:PlaceKind; slotLabel?:string; onClose: () => void; onAdd: (place: Place, stay?: StayChoice) => string | null };
function Distance({ anchor, place }: { anchor: Place; place: Place }) {
  const distance = distanceBetween(anchor, place);
  return <>{distance === null ? '위치 미확인' : distance < 1 ? `직선 ${Math.round(distance * 1000)}m` : `직선 ${distance.toFixed(1)}km`}</>;
}
function CandidateDetail({ place, anchor, added, journey, dayId, onAdd }: {place:Place;anchor:Place;added:boolean;journey:Journey;dayId:string;onAdd:Props['onAdd']}) {
  const [error,setError]=useState('');
  const [stay,setStay]=useState(false);
  return <div className="plan-form">{place.image&&<img className="nearby-detail-image" src={place.image} alt={place.name}/>}<p>{place.description||'등록된 상세 설명이 없어요.'}</p><p className="plan-help">{place.address||'주소 확인 필요'} · <Distance anchor={anchor} place={place}/></p><p className="plan-help">방문 전 운영 정보를 확인해 주세요.</p>{stay?<StayForm journey={journey} dayId={dayId} onSubmit={choice=>onAdd(place,choice)}/>:<Button disabled={added} onClick={()=>{if(place.kind==='STAY')setStay(true);else setError(onAdd(place)||'');}}>{added?'담긴 장소':place.kind==='STAY'?'숙박일 선택':'이 장소 담기'}</Button>}{error&&<p className="ui-error" role="alert">{error}</p>}</div>;
}
export function StayForm({journey,dayId,onSubmit}:{journey:Journey;dayId:string;onSubmit:(choice:StayChoice)=>string|null}) {
  const [start,setStart]=useState(journey.days.slice(0,-1).some(day=>day.dayId===dayId)?dayId:'');
  const [nights,setNights]=useState(1),[fixed,setFixed]=useState(false),[error,setError]=useState('');
  const index=journey.days.findIndex(day=>day.dayId===start),max=index<0?0:journey.days.length-index-1;
  return <>{journey.days.length<2?<p>당일 여행이에요. 숙박이 필요하면 내 여행에서 DAY를 추가해 주세요.</p>:<><Field label="숙박 시작일"><select value={start} onChange={event=>{setStart(event.target.value);setNights(1);}}><option value="">숙박할 DAY 선택</option>{journey.days.slice(0,-1).map(day=><option key={day.dayId} value={day.dayId}>DAY {day.day} 숙박</option>)}</select></Field><Field label="숙박 기간"><select value={nights} disabled={!max} onChange={event=>setNights(Number(event.target.value))}>{Array.from({length:max||1},(_,i)=><option key={i} value={i+1}>{i+1}박</option>)}</select></Field><label className="plan-check"><input type="checkbox" checked={fixed} onChange={event=>setFixed(event.target.checked)}/>예약한 숙소로 고정</label><p className="plan-help">선택한 날의 마지막 장소와 다음 날의 출발지로 보여요. 같은 날의 기존 숙소는 교체돼요.</p><Button disabled={!max||nights>max} onClick={()=>setError(onSubmit({dayId:start,nights,fixed})||'')}>숙소 담기</Button>{error&&<p className="ui-error" role="alert">{error}</p>}</>}</>;
}
function Candidate({ place, anchor, added, onChoose,journey,dayId,onAdd }: { place: Place; anchor: Place; added: boolean; onChoose: (place: Place) => void;journey:Journey;dayId:string;onAdd:Props['onAdd'] }) {
  const detail = useBottomSheetDetail();
  return <article className="nearby-business">
    <div className="nearby-row"><button className="nearby-open" aria-label={`${place.name} 상세`} onClick={() => detail?.({ title: place.name, children: <CandidateDetail place={place} anchor={anchor} added={added} journey={journey} dayId={dayId} onAdd={onAdd}/> })}>{place.image ? <img src={place.image} alt="" /> : <span className="plan-image-empty"><MapPin size={22} /></span>}<span><strong>{place.name}</strong><small><Distance anchor={anchor} place={place} /></small><small>{place.address || '주소 확인 필요'}</small></span></button><button className="outline" disabled={added} onClick={() => onChoose(place)}>{added ? '담김' : '담기'}</button></div>
    <PhotoCredit image={place.image} />
  </article>;
}
export function NearbyBusinessSheet({ journey, dayId, anchor, catalog, savedPlaces, initialKind='FOOD', slotLabel, onClose, onAdd }: Props) {
  const [kind, setKind] = useState<PlaceKind>(initialKind);
  const [query, setQuery] = useState('');
  const [source, setSource] = useState<'nearby'|'saved'>('nearby');
  const [manual, setManual] = useState(false);
  const [name, setName] = useState('');
  const [address, setAddress] = useState('');
  const [stayPlace, setStayPlace] = useState<Place | null>(null);
  const [stayDay, setStayDay] = useState(journey.days.findIndex(day => day.dayId === dayId) < journey.days.length - 1 ? dayId : '');
  const [nights, setNights] = useState(1);
  const [fixed, setFixed] = useState(false);
  const [error, setError] = useState('');
  const day = journey.days.find(day => day.dayId === dayId);
  const results = useMemo(() => {
    const candidates = source === 'saved' ? savedPlaces.filter(place => place.kind === kind) : query.trim()
      ? [...new Map(catalog.filter(place => place.kind === kind && place.area.split(' ')[0] === anchor.area.split(' ')[0]).map(place => [place.id, place])).values()]
      : nearbyCandidates(anchor, catalog, kind);
    const term = query.trim().toLocaleLowerCase();
    return candidates.filter(place => !term || `${place.name} ${place.address}`.toLocaleLowerCase().includes(term));
  }, [anchor, catalog, kind, query, source, savedPlaces]);
  const submit = (place: Place, stay?: StayChoice) => { const problem = onAdd(place, stay); if (problem) setError(problem); };
  const choose = (place: Place) => { setError(''); if (place.kind === 'STAY') setStayPlace(place); else submit(place); };
  const stayStart = journey.days.findIndex(day => day.dayId === stayDay);
  const maxNights = stayStart < 0 ? 0 : journey.days.length - stayStart - 1;
  return <BottomSheet title={stayPlace ? '숙박일에 숙소 담기' : manual ? '내 일정에 업체 등록' : `${anchor.name} 주변`} description={`DAY ${day?.day ?? ''}${slotLabel?` · ${slotLabel}`:''} · ${anchor.name}에서 이어지는 일정`} onClose={onClose}>
    <div className="plan-form">
      {stayPlace ? <>
        <button className="plan-back" onClick={() => { setStayPlace(null); setError(''); }}><ArrowLeft size={16} />업체 목록으로</button><h3>{stayPlace.name}</h3>
        {journey.days.length < 2 ? <p>당일 여행이에요. 숙박이 필요하면 내 여행에서 DAY를 추가해 주세요.</p> : <>
          <Field label="숙박 시작일"><select value={stayDay} onChange={event => { setStayDay(event.target.value); setNights(1); }}><option value="">숙박할 DAY 선택</option>{journey.days.slice(0,-1).map(day => <option key={day.dayId} value={day.dayId}>DAY {day.day} 밤</option>)}</select></Field>
          <Field label="숙박 기간"><select value={nights} disabled={!maxNights} onChange={event => setNights(Number(event.target.value))}>{Array.from({length:Math.max(1,maxNights)},(_,i)=>i+1).map(night=><option key={night} value={night}>{night}박</option>)}</select></Field>
          <label className="plan-check"><input type="checkbox" checked={fixed} onChange={event=>setFixed(event.target.checked)} />예약한 숙소로 고정</label>
          <p className="plan-help">해당 밤의 숙소만 바뀌어요. 예약한 숙소가 고정돼 있으면 먼저 고정을 해제해 주세요.</p>
          <Button disabled={!maxNights} onClick={()=>submit(stayPlace,{dayId:stayDay,nights,fixed})}>이 숙소 담기</Button>
        </>}
      </> : manual ? <>
        <button className="plan-back" onClick={()=>{setManual(false);setError('');}}><ArrowLeft size={16}/>업체 목록으로</button>
        <Field label="업체명"><input value={name} maxLength={80} onChange={event=>setName(event.target.value)} placeholder="예: 바다 앞 식당" /></Field>
        <Field label="주소"><input value={address} maxLength={200} onChange={event=>setAddress(event.target.value)} placeholder="알고 있는 주소를 적어주세요" /></Field>
        <p className="plan-help">내 여행에만 담겨요. 위치가 확인되기 전에는 지도와 거리가 표시되지 않아요.</p>
        <Button disabled={!name.trim() || !address.trim()} onClick={()=>choose({id:`personal-${crypto.randomUUID()}`,kind,name:name.trim(),address:address.trim(),area:anchor.area,lat:NaN,lng:NaN,locationVerified:false,personal:true,image:'',photos:[],description:'',note:'',duration:''})}>내 일정에 담기</Button>
      </> : <>
        <div className="saved-region-chips" role="group" aria-label="주변 업체 종류">{(['FOOD','CAFE','STAY'] as const).map(value=><button key={value} aria-pressed={kind===value} className={kind===value?'active':''} onClick={()=>{setKind(value);setError('');}}>{value==='FOOD'?'맛집':value==='CAFE'?'카페':'숙소'}</button>)}</div>
        <label className="nearby-search"><Search size={17}/><input aria-label="주변 업체 검색" value={query} onChange={event=>setQuery(event.target.value)} placeholder="업체명 검색" /></label>
        <p className="plan-help">{source==='saved'?'저장한 업체에서 고르기':'가까운 장소 예시 · 직선거리 기준'}{query && ' · 지역 내 검색'}</p>
        <div className="nearby-results">{results.map(place=><Candidate key={place.id} place={place} anchor={anchor} journey={journey} dayId={dayId} onAdd={onAdd} added={place.kind!=='STAY' && Boolean(day?.places.some(visit=>visit.id===place.id && visit.anchorVisitId===anchor.visitId))} onChoose={choose}/>)}</div>
        {!results.length && <div className="empty"><MapPin size={24}/><strong>{source==='saved'?'저장한 업체가 없어요':'조건에 맞는 업체가 없어요'}</strong><p>다른 이름으로 찾거나 아는 곳을 직접 담아보세요.</p></div>}
        <button className="outline nearby-saved-button" onClick={()=>{setSource(source==='nearby'?'saved':'nearby');setError('');}}><Bookmark size={14}/>{source==='nearby'?'저장한 장소에서 고르기':'주변 추천으로 돌아가기'}</button>
        <button className="plan-text-button nearby-register-button" onClick={()=>{setManual(true);setName(query);setError('');}}><Plus size={14}/>찾는 곳이 없나요? 직접 등록</button>
      </>}
      {error && <p className="ui-error" role="alert">{error}</p>}
    </div>
  </BottomSheet>;
}
